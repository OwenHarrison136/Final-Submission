﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace Uni_Work
{
    class Program
    {
        static void DisplayBoard(string[,] board)
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            for (int i = 1; i <= board.GetLength(1); i++)
            {
                
                Console.Write(i.ToString().PadRight(1).PadLeft(3));
            }
            Console.WriteLine();
            int N = 0;
            Console.ForegroundColor = ConsoleColor.White;
            for (int i = 0; i < board.GetLength(0); i++)
            {
                N++;
                Console.Write(N);
                for (int j = 0; j < board.GetLength(1); j++)
                {
                    
                    Console.Write(board[i, j].ToString().PadRight(1).PadLeft(3));
                }
                Console.WriteLine("".PadRight(1));
            }
        }
        static void DisplayBoardnonehardcode(char[,] board)
        {
            for (int i = 1; i <= board.GetLength(1); i++)
            {
                Console.Write(i.ToString().PadRight(1).PadLeft(3));
            }
            Console.WriteLine();
            int N = 0;

            for (int i = 0; i <= board.GetLength(0); i++)
            {
                N++;
                Console.Write(N);
                for (int j = 0; j < board.GetLength(1); j++)
                {
                    Console.Write(board[i, j].ToString().PadRight(1).PadLeft(3));
                }
                Console.WriteLine("".PadRight(1));
            }
        }
        static void PutWordOnBoardright(char[,] board, int Row, int Col, string Word, string Direction)
        {
            char[] letters = new char[Word.Length];

            int T = 0;
            while (T < letters.Length)
            {
                letters[T] = Word[T];
                T++;
            }
            int count = 0;
            Console.WriteLine(Direction);
            while (count < letters.Length)
            {
                board[Row, Col] = letters[count];
                count++;
                Col++;
            }

            DisplayBoardnonehardcode(board);
            return;
        }
        static void PutWordOnBoardleft(char[,] board, int Row, int Col, string Word, string Direction)
        {
            char[] letters = new char[Word.Length];

            int T = 0;
            while (T < letters.Length)
            {
                letters[T] = Word[T];
                T++;
            }
            int count = 0;
            Console.WriteLine(Direction);
            while (count < letters.Length)
            {
                board[Row, Col] = letters[count];
                count++;
                Col--;
            }

            DisplayBoardnonehardcode(board);
            return;
        }
        static void PutWordOnBoardup(char[,] board, int Row, int Col, string Word, string Direction)
        {
            char[] letters = new char[Word.Length];

            int T = 0;
            while (T < letters.Length)
            {
                letters[T] = Word[T];
                T++;
            }
            int count = 0;
            Console.WriteLine(Direction);
            while (count < letters.Length)
            {
                board[Row, Col] = letters[count];
                count++;
                Row--;
            }

            DisplayBoardnonehardcode(board);
            return;
        }
        static void PutWordOnBoarddown(char[,] board, int Row, int Col, string Word, string Direction)
        {
            char[] letters = new char[Word.Length];

            int T = 0;
            while (T < letters.Length)
            {
                letters[T] = Word[T];
                T++;
            }
            int count = 0;
            Console.WriteLine(Direction);
            while (count < letters.Length)
            {
                board[Row, Col] = letters[count];
                count++;
                Row++;
            }

            DisplayBoardnonehardcode(board);
            return;
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to the Wordsearch!");
            Console.WriteLine("Please select an option. ");
            Console.WriteLine("1. Default Wordsearch");
            Console.WriteLine("2. Load Wordsearch from file");
            Console.WriteLine("3. Resume last saved wordsearch");
            string answer = ("");
            while (answer != "1" || answer != "2" || answer != "3")
            {
                answer = (Console.ReadLine());

                if (answer == "1")
                {
                    DefaultWordsearch();
                    break;
                }
                if (answer == "2")
                {
                    SecondWordsearch();
                    break;
                }
                if (answer == "2")
                {
                    SecondWordsearch();
                    break;
                }
                else
                {
                    Console.WriteLine("Please enter '1', '2' or '3'");
                }
            }
            Console.WriteLine();
            Console.WriteLine("Press any key to exit.");
            Console.ReadKey();
        }
        private static void SecondWordsearch()
        {
            string[] Files = Directory.GetFiles(Directory.GetCurrentDirectory(), "*.wrd");

            for (int i = 0; i <= 6; i++)
            {
                Console.WriteLine((i + 1) + "." + Files[i]);
            }
            Console.WriteLine("Please select a file between 1 and 7");
            Console.WriteLine("1-7");
            int answernumber = (1);
            string answer1 = ("");
            do
            {
                answer1 = Console.ReadLine();
                answernumber = int.Parse(answer1);
                answernumber = (answernumber - 1);
            }
            while (answernumber <= 0 && answernumber >= 6);

            answernumber = int.Parse(answer1);
            answernumber = (answernumber - 1);

            Console.Clear();

            int scorenew = 0;
            string readfile = File.ReadAllText(Files[answernumber]);
            string[] split = readfile.Split(',', '\n');
            scorenew = (readfile[4] - '0');
            string[] words = new string[scorenew];
            int splitlength = split.Length + 2;
            int X = 0;
            int N = 3;

            while (X < words.Length)
            {
                words[X] = split[N];
                N = N + 4;
                X++;
            }

            int readcol = int.Parse(split[0]);
            int readrow = int.Parse(split[1]);

            char[,] board = new char[readrow, readcol];
            Random random = new Random();
            char[,] array = new char[readrow, readcol];

            for (int x = 0; x < array.GetLength(0); ++x)
            {
                for (int y = 0; y < array.GetLength(1); ++y)
                {
                    array[x, y] = (char)(random.Next(65, 91));
                }
            }

            string word1 = words[0];
            string direction = split[6];
            int row = int.Parse(split[5]);
            int col = int.Parse(split[4]);
            int startrow = 5;
            int startcol = 4;
            int directionnum = 6;
            int wordnumber = 0;
            int count = 1;
            int wordcount = words.Length;
            string W = split[directionnum];
            Console.WriteLine(W);
            while (count <= wordcount)
            {
                //Console.WriteLine(dy[0]);
                //Console.WriteLine(split[directionnum]);

                if (split[directionnum] == "right\r")
                {
                    string dy = split[directionnum];
                    Console.WriteLine(wordcount);
                    Console.WriteLine("row " + int.Parse(split[startrow]));
                    Console.WriteLine("col " + int.Parse(split[startcol]));
                    Console.WriteLine("direction " + split[directionnum]);
                    PutWordOnBoardright(board: array, Row: int.Parse(split[startrow]), Col: int.Parse(split[startcol]), Word: (split[wordnumber]), Direction: (split[directionnum]));
                    startrow = startrow + 4;
                    startcol = startcol + 4;
                    wordnumber++;
                    wordcount--;
                }
                else if (split[directionnum] == "left\r")
                {
                    string dy = split[directionnum];
                    Console.WriteLine(wordcount);
                    Console.WriteLine("row " + int.Parse(split[startrow]));
                    Console.WriteLine("col " + int.Parse(split[startcol]));
                    Console.WriteLine("direction " + split[directionnum]);
                    PutWordOnBoardleft(board: array, Row: int.Parse(split[startrow]), Col: int.Parse(split[startcol]), Word: (split[wordnumber]), Direction: (split[directionnum]));
                    startrow = startrow + 4;
                    startcol = startcol + 4;
                    wordnumber++;
                    wordcount--;
                }
                else if (split[directionnum] == "down\r")
                {
                    string dy = split[directionnum];
                    Console.WriteLine(wordcount);
                    Console.WriteLine("row " + int.Parse(split[startrow]));
                    Console.WriteLine("col " + int.Parse(split[startcol]));
                    Console.WriteLine("direction " + split[directionnum]);
                    PutWordOnBoarddown(board: array, Row: int.Parse(split[startrow]), Col: int.Parse(split[startcol]), Word: (split[wordnumber]), Direction: (split[directionnum]));
                    startrow = startrow + 4;
                    startcol = startcol + 4;
                    wordnumber++;
                    wordcount--;
                }
                else if (split[directionnum] == "up\r")
                {
                    string dy = split[directionnum];
                    Console.WriteLine(wordcount);
                    Console.WriteLine("row " + int.Parse(split[startrow]));
                    Console.WriteLine("col " + int.Parse(split[startcol]));
                    Console.WriteLine("direction " + split[directionnum]);
                    PutWordOnBoardup(board: array, Row: int.Parse(split[startrow]), Col: int.Parse(split[startcol]), Word: (split[wordnumber]), Direction: (split[directionnum]));
                    startrow = startrow + 4;
                    startcol = startcol + 4;
                    wordnumber++;
                    wordcount--;
                }
            }
            Console.WriteLine("The amount of the words in the wordsearch are " + scorenew);
            Console.WriteLine("The words to look for are: ");
            for (int i = 0; i < words.Length;)
            {
                Console.WriteLine(words[i]);
                i++;
            }
        }
        private static void DefaultWordsearch()
        {
            string[,] board = new string[5, 9]
            {
                {"l","t","e","g","q","h","g","t","r"},
                {"a","l","g","o","r","i","t","h","m"},
                {"c","e","m","x","m","b","t","j","g"},
                {"a","f","k","r","e","m","p","q","c"},
                {"s","s","u","r","i","v","r","g","y"},
            };

            Console.Clear();
            DisplayBoard(board);

            string answer1 = ("algorithm");
            string answer2 = ("virus");
            int score = (0);

            Console.WriteLine("How to Play:");
            Console.WriteLine("1. Input the col and row of the first letter");
            Console.WriteLine("2. Input the col and row of the last letter");

            while (score != 2)
            {
                Console.WriteLine("Please input the first letters column");
                string ColInput1 = Console.ReadLine();
                Console.WriteLine("Please input the first letters row");
                string RowInput1 = Console.ReadLine();
                int ColInput = int.Parse(ColInput1) - 1;
                int RowInput = int.Parse(RowInput1) - 1;

                Console.WriteLine("Please input the last letters column");
                string EndColInput1 = Console.ReadLine();
                Console.WriteLine("Please input the last letters row");
                string EndRowInput1 = Console.ReadLine();
                int EndColInput = int.Parse(EndColInput1) - 1;
                int EndRowInput = int.Parse(EndRowInput1) - 1;

                string[] wordArray = new string[10];
                int x = 0;

                if (ColInput < EndColInput)
                {
                    while (ColInput <= EndColInput)
                    {
                        string selection = (board[RowInput, ColInput]);
                        ColInput++;
                        wordArray[x] = (selection);
                        x++;
                    }
                }
                else if (ColInput > EndColInput)
                {
                    while (ColInput >= EndColInput)
                    {
                        string selection = (board[RowInput, ColInput]);
                        ColInput--;
                        wordArray[x] = (selection);
                        x++;
                    }
                }
                string word = "";
                for (int i = 0; i < wordArray.Length; i++)
                {
                    word = word + (wordArray[i]);
                }

                if (word == answer1)
                {
                    score++;
                    Console.WriteLine("Your score is " + score);
                }
                if (word == answer1)
                {
                    score++;
                    Console.WriteLine("Your score is " + score);
                }
                if (word != answer1 && word != answer2)
                {
                    Console.WriteLine(word + " is not a word in the wordsearch");
                }
            }
            Console.WriteLine("Congratulations, you found both the words!");
        }
    }
}